// ── GLOBAL STATE ───────────────────────────────────────────────
let currentUser = null;
let allPosts = [];
let allUsers = [];
let notifPollTimer = null;

// ── API UTILITIES ──────────────────────────────────────────────
const API_URL = "https://circle-backend-demo.vercel.app";

async function api(method, path, body = null) {
  const opts = {
    method,
    headers: { "Content-Type": "application/json" },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API_URL + path, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}

// ── THEME ──────────────────────────────────────────────────────
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("circle_theme", theme);
  updateThemeButtons();
}

function updateThemeButtons() {
  const theme = document.documentElement.getAttribute("data-theme");
  document.querySelectorAll(".theme-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.theme === theme);
  });
}

function toggleTheme(theme) {
  applyTheme(theme);
}

// ── USER AUTHENTICATION ────────────────────────────────────────
function setCurrentUser(user) {
  currentUser = user;
  localStorage.setItem("circle_user", JSON.stringify(user));
  updateUserChip();
  startNotifPolling();
}

function updateUserChip() {
  const chip = document.getElementById("user-chip");
  if (!chip) return;

  if (currentUser) {
    const color = stringToColor(currentUser.name || "U");
    const initial = (currentUser.name || "U")[0].toUpperCase();
    const avHtml = currentUser.profilePicture
      ? `<img src="${currentUser.profilePicture}" alt="${currentUser.name}">`
      : initial;
    chip.innerHTML = `
      <div class="av" style="background:${currentUser.profilePicture ? "transparent" : color}">
        ${avHtml}
      </div>
      <div class="user-info">
        <div class="user-info-name">${escHtml(currentUser.name)}</div>
        <div class="user-info-sub">@${escHtml(currentUser.username)}</div>
      </div>
    `;
    chip.onclick = () => (window.location.href = "profile.html");
  } else {
    chip.innerHTML = `
      <div class="av" style="background:var(--txt3)">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="18" height="18">
          <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
        </svg>
      </div>
      <div class="user-info">
        <div class="user-info-name">Guest</div>
        <div class="user-info-sub">Not logged in</div>
      </div>
    `;
    chip.onclick = () => {
      showToast("Please log in to continue");
      setTimeout(() => (window.location.href = "index.html"), 1000);
    };
  }
}

async function logout() {
  currentUser = null;
  localStorage.removeItem("circle_user");
  stopNotifPolling();
  showToast("Logged out successfully");
  setTimeout(() => (window.location.href = "index.html"), 800);
}

// ── POSTS ──────────────────────────────────────────────────────
async function loadPosts() {
  try {
    const res = await api("GET", "/api/posts");
    allPosts = res.data || [];
    renderPosts(allPosts);
  } catch (e) {
    console.error("Error loading posts:", e);
  }
}

function renderPosts(posts) {
  const feed = document.getElementById("feed");
  if (!feed) return;

  if (!posts || posts.length === 0) {
    feed.innerHTML = `
      <div class="feed-empty">
        <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
          <path d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/>
        </svg>
        <div class="feed-empty-title">No posts yet</div>
        <div>Be the first to share something!</div>
      </div>
    `;
    return;
  }

  feed.innerHTML = posts.map((p) => buildPostCard(p)).join("");
}

function buildPostCard(post) {
  const author = allUsers.find((u) => u.id === post.authorId) || {
    name: "Unknown User",
    username: "unknown",
  };
  const color = stringToColor(author.name || "U");
  const initial = (author.name || "U")[0].toUpperCase();
  const avHtml = author.profilePicture
    ? `<img src="${author.profilePicture}" alt="${author.name}">`
    : initial;

  const isLiked = currentUser && post.likes?.includes(currentUser.id);
  const isBookmarked = currentUser && post.bookmarks?.includes(currentUser.id);

  return `
    <div class="post" data-post-id="${post.id}">
      <div class="post-header">
        <div class="av" style="background:${author.profilePicture ? "transparent" : color}" onclick="viewProfile('${author.id}')">
          ${avHtml}
        </div>
        <div class="post-info">
          <div class="post-author" onclick="viewProfile('${author.id}')">
            ${escHtml(author.name)}
            <span class="post-username">@${escHtml(author.username)}</span>
          </div>
          <div class="post-time">${formatTime(post.createdAt)}</div>
        </div>
        <button class="post-menu-btn" onclick="openPostMenu('${post.id}')">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>
          </svg>
        </button>
      </div>
      <div class="post-content">${escHtml(post.content)}</div>
      ${post.image ? `<div class="post-image"><img src="${post.image}" alt="Post image"></div>` : ""}
      <div class="post-actions">
        <button class="post-action ${isLiked ? "active like" : ""}" onclick="toggleLike('${post.id}')">
          <svg fill="${isLiked ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
          </svg>
          <span class="count">${post.likes?.length || 0}</span>
        </button>
        <button class="post-action" onclick="showToast('Comments coming soon!')">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
          </svg>
          <span class="count">${post.comments?.length || 0}</span>
        </button>
        <button class="post-action" onclick="showToast('Sharing coming soon!')">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8M16 6l-4-4-4 4M12 2v13"/>
          </svg>
        </button>
        <button class="post-action ${isBookmarked ? "active" : ""}" onclick="toggleBookmark('${post.id}')" style="margin-left:auto">
          <svg fill="${isBookmarked ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/>
          </svg>
        </button>
      </div>
    </div>
  `;
}

async function createPost() {
  if (!currentUser) {
    showToast("Please log in to post");
    return;
  }

  const textarea = document.getElementById("composer-textarea");
  const content = textarea.value.trim();
  const imageInput = document.getElementById("composer-image-input");
  const preview = document.getElementById("composer-image-preview");

  if (!content) {
    showToast("Post cannot be empty");
    return;
  }

  const btn = document.getElementById("composer-post-btn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>';

  try {
    let imageUrl = null;
    if (imageInput.files.length > 0) {
      imageUrl = await uploadImage(imageInput.files[0]);
    }

    const newPost = {
      content,
      authorId: currentUser.id,
      image: imageUrl,
      likes: [],
      comments: [],
      bookmarks: [],
      createdAt: new Date().toISOString(),
    };

    const res = await api("POST", "/api/posts", newPost);
    textarea.value = "";
    imageInput.value = "";
    if (preview) preview.style.display = "none";
    showToast("Posted successfully! ✨");
    loadPosts();
  } catch (e) {
    showToast("Error: " + e.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = "Post";
  }
}

async function toggleLike(postId) {
  if (!currentUser) {
    showToast("Log in to like posts");
    return;
  }

  try {
    await api("POST", `/api/posts/${postId}/like`, {
      userId: currentUser.id,
    });
    loadPosts();
  } catch (e) {
    showToast("Error: " + e.message);
  }
}

async function toggleBookmark(postId) {
  if (!currentUser) {
    showToast("Log in to bookmark posts");
    return;
  }

  try {
    await api("POST", `/api/posts/${postId}/bookmark`, {
      userId: currentUser.id,
    });
    loadPosts();
  } catch (e) {
    showToast("Error: " + e.message);
  }
}

async function deletePost(postId) {
  if (!confirm("Delete this post?")) return;

  try {
    await api("DELETE", `/api/posts/${postId}`);
    showToast("Post deleted");
    loadPosts();
  } catch (e) {
    showToast("Error: " + e.message);
  }
}

function openPostMenu(postId) {
  showToast("Post menu coming soon!");
}

// ── IMAGE UPLOAD ───────────────────────────────────────────────
async function uploadImage(file) {
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(API_URL + "/api/upload", {
    method: "POST",
    body: formData,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Upload failed");
  return data.url;
}

function onComposerImageSelect(input) {
  const preview = document.getElementById("composer-image-preview");
  if (!preview) return;

  if (input.files.length > 0) {
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      preview.innerHTML = `
        <img src="${e.target.result}" alt="Preview">
        <button class="composer-image-remove" onclick="removeComposerImage()">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      `;
      preview.style.display = "block";
    };
    reader.readAsDataURL(file);
  }
}

function removeComposerImage() {
  const input = document.getElementById("composer-image-input");
  const preview = document.getElementById("composer-image-preview");
  if (input) input.value = "";
  if (preview) preview.style.display = "none";
}

// ── USERS ──────────────────────────────────────────────────────
async function loadUsers() {
  try {
    const res = await api("GET", "/api/users");
    allUsers = res.data || [];
  } catch (e) {
    console.error("Error loading users:", e);
  }
}

async function loadUserProfile(userId) {
  try {
    const res = await api("GET", `/api/users/${userId}`);
    return res.data;
  } catch (e) {
    console.error("Error loading user profile:", e);
    return null;
  }
}

async function loadUserPosts(userId) {
  try {
    const res = await api("GET", `/api/posts?authorId=${userId}`);
    return res.data || [];
  } catch (e) {
    console.error("Error loading user posts:", e);
    return [];
  }
}

function viewProfile(userId) {
  window.location.href = `profile.html?id=${userId}`;
}

async function toggleFollow(userId) {
  if (!currentUser) {
    showToast("Log in to follow users");
    return;
  }

  try {
    await api("POST", `/api/users/${userId}/follow`, {
      followerId: currentUser.id,
    });
    
    // Reload current user data
    const res = await api("GET", `/api/users/${currentUser.id}`);
    setCurrentUser(res.data);
    
    // Update UI
    const btn = document.querySelector(`[onclick="toggleFollow('${userId}')"]`);
    if (btn) {
      const isFollowing = currentUser.following?.includes(userId);
      btn.textContent = isFollowing ? "Following" : "Follow";
      btn.classList.toggle("following", isFollowing);
    }
    
    showToast(currentUser.following?.includes(userId) ? "Following!" : "Unfollowed");
  } catch (e) {
    showToast("Error: " + e.message);
  }
}

// ── SEARCH ─────────────────────────────────────────────────────
async function performSearch(query, type = "all") {
  if (!query.trim()) {
    document.getElementById("search-results").innerHTML = "";
    return;
  }

  const results = document.getElementById("search-results");
  results.innerHTML = '<div style="text-align:center;padding:40px;color:var(--txt3)">Searching...</div>';

  try {
    if (type === "users" || type === "all") {
      const res = await api("GET", `/api/users?q=${encodeURIComponent(query)}`);
      const users = res.data || [];
      renderSearchResults(users, type);
    }
  } catch (e) {
    results.innerHTML = '<div style="text-align:center;padding:40px;color:var(--rose)">Search failed</div>';
  }
}

function renderSearchResults(users, type) {
  const results = document.getElementById("search-results");
  
  if (!users || users.length === 0) {
    results.innerHTML = '<div style="text-align:center;padding:40px;color:var(--txt3)">No results found</div>';
    return;
  }

  results.innerHTML = users
    .map((user) => {
      const color = stringToColor(user.name || "U");
      const initial = (user.name || "U")[0].toUpperCase();
      const avHtml = user.profilePicture
        ? `<img src="${user.profilePicture}" alt="${user.name}">`
        : initial;
      const isFollowing = currentUser && currentUser.following?.includes(user.id);

      return `
        <div class="user-result">
          <div class="av" style="background:${user.profilePicture ? "transparent" : color}" onclick="viewProfile('${user.id}')">
            ${avHtml}
          </div>
          <div class="user-result-info" onclick="viewProfile('${user.id}')" style="cursor:pointer">
            <div class="user-result-name">${escHtml(user.name)}</div>
            <div class="user-result-username">@${escHtml(user.username)}</div>
            ${user.bio ? `<div class="user-result-bio">${escHtml(user.bio)}</div>` : ""}
          </div>
          ${currentUser && currentUser.id !== user.id ? `
            <button class="follow-btn ${isFollowing ? "following" : ""}" onclick="toggleFollow('${user.id}')">
              ${isFollowing ? "Following" : "Follow"}
            </button>
          ` : ""}
        </div>
      `;
    })
    .join("");
}

// ── NOTIFICATIONS ──────────────────────────────────────────────
async function fetchUnreadCount() {
  if (!currentUser) return;
  try {
    const res = await api("GET", `/api/notifications/${currentUser.id}/unread-count`);
    const count = res.count || 0;
    const badge = document.getElementById("notif-badge");
    if (badge) {
      if (count > 0) {
        badge.textContent = count > 9 ? "9+" : count;
        badge.style.display = "block";
      } else {
        badge.style.display = "none";
      }
    }
  } catch (e) {
    console.error("Error fetching notification count:", e);
  }
}

async function fetchNotifications() {
  if (!currentUser) return;
  try {
    const res = await api("GET", `/api/notifications/${currentUser.id}`);
    const notifs = res.data || [];
    renderNotifications(notifs);
  } catch (e) {
    console.error("Error fetching notifications:", e);
  }
}

function renderNotifications(notifs) {
  const list = document.getElementById("notif-list");
  if (!list) return;

  if (!notifs || notifs.length === 0) {
    list.innerHTML = `
      <div class="notif-empty">
        <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
          <path d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"/>
        </svg>
        No notifications yet
      </div>
    `;
    return;
  }

  const NOTIF_ICONS = {
    like: '<svg fill="currentColor" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>',
    comment: '<svg fill="currentColor" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
    follow: '<svg fill="currentColor" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M8.5 11a4 4 0 100-8 4 4 0 000 8zM20 8v6M23 11h-6"/></svg>',
  };

  const NOTIF_COPY = {
    like: (name) => `${name} liked your post`,
    comment: (name) => `${name} commented on your post`,
    follow: (name) => `${name} started following you`,
  };

  list.innerHTML = notifs
    .map((n) => {
      const color = stringToColor(n.actorName || "U");
      const initial = (n.actorName || "U")[0].toUpperCase();
      const avHtml = n.actorPicture
        ? `<img src="${n.actorPicture}" alt="${n.actorName}">`
        : initial;

      return `
    <div class="notif-item ${n.isRead ? "" : "unread"}" onclick="onNotifClick('${n.id}', '${n.postId || ""}')">
      <div class="av sm" style="background:${n.actorPicture ? "transparent" : color}">${avHtml}</div>
      <div class="notif-body-text">
        <div class="notif-text">${(NOTIF_COPY[n.type] || NOTIF_COPY.like)(n.actorName || "Someone")}</div>
        ${n.postSnippet ? `<div class="notif-snippet">"${escHtml(n.postSnippet)}"</div>` : ""}
        <div class="notif-time">${formatTime(n.createdAt)}</div>
      </div>
      <div class="notif-icon ${n.type}">${NOTIF_ICONS[n.type] || ""}</div>
      ${!n.isRead ? '<div class="notif-dot"></div>' : ""}
    </div>`;
    })
    .join("");
}

async function onNotifClick(notifId, postId) {
  try {
    await api("PUT", `/api/notifications/${notifId}/read`);
  } catch (e) {
    /* silent */
  }
  closeNotifPanel();
  
  if (postId) {
    window.location.href = `index.html#post-${postId}`;
  }
  
  fetchNotifications();
}

async function markAllRead() {
  if (!currentUser) return;
  try {
    await api("PUT", `/api/notifications/${currentUser.id}/read-all`);
    fetchNotifications();
    showToast("All notifications marked as read ✓");
  } catch (e) {
    showToast("Error: " + e.message);
  }
}

function openNotifPanel() {
  if (!currentUser) {
    showToast("Log in to see notifications.");
    return;
  }
  fetchNotifications();
  document.getElementById("notif-panel").classList.add("open");
  document.getElementById("notif-backdrop").classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeNotifPanel() {
  document.getElementById("notif-panel").classList.remove("open");
  document.getElementById("notif-backdrop").classList.remove("open");
  document.body.style.overflow = "";
}

function startNotifPolling() {
  stopNotifPolling();
  fetchUnreadCount();
  notifPollTimer = setInterval(fetchUnreadCount, 30000);
}

function stopNotifPolling() {
  if (notifPollTimer) {
    clearInterval(notifPollTimer);
    notifPollTimer = null;
  }
}

// ── SUGGESTIONS ────────────────────────────────────────────────
let _suggestionsLoaded = false;

async function loadSuggestions(force = false) {
  if (!currentUser) return;
  if (_suggestionsLoaded && !force) return;

  const section = document.getElementById("suggestions-section");
  const listEl = document.getElementById("suggestions-list");
  const refreshBtn = document.getElementById("sug-refresh-btn");

  if (!section || !listEl) return;
  section.style.display = "block";

  // Skeleton loading
  listEl.innerHTML = [1, 2, 3, 4]
    .map(
      () =>
        '<div class="sug-skeleton">' +
        '<div class="sug-skel-av"></div>' +
        '<div class="sug-skel-line" style="width:80%"></div>' +
        '<div class="sug-skel-line" style="width:55%"></div>' +
        '<div class="sug-skel-btn"></div>' +
        "</div>"
    )
    .join("");

  if (refreshBtn) {
    refreshBtn.classList.add("spinning");
    refreshBtn.disabled = true;
  }

  try {
    const res = await api(
      "GET",
      "/api/recommendations?userId=" + currentUser.id + "&limit=10"
    );
    const users = res.data || [];

    if (!users.length) {
      listEl.innerHTML =
        '<div class="suggestions-empty">' +
        '<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" width="28" height="28" style="margin:0 auto 8px;display:block;color:var(--txt3)">' +
        '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>' +
        '<path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>' +
        "Interact with posts to get suggestions!</div>";
    } else {
      listEl.innerHTML = users.map((u) => buildSuggestionCard(u)).join("");
    }
    _suggestionsLoaded = true;
  } catch (e) {
    listEl.innerHTML =
      '<div class="suggestions-empty" style="color:var(--rose)">Could not load suggestions.</div>';
    console.error("Suggestions error:", e);
  } finally {
    if (refreshBtn) {
      refreshBtn.classList.remove("spinning");
      refreshBtn.disabled = false;
    }
  }
}

function buildSuggestionCard(user) {
  const color = stringToColor(user.name || "U");
  const initial = (user.name || "U")[0].toUpperCase();
  const avHtml = user.profilePicture
    ? `<img src="${user.profilePicture}" alt="${user.name}">`
    : initial;
  const isFollowing = currentUser && currentUser.following?.includes(user.id);

  return `
    <div class="sug-card">
      <div class="av sm" style="background:${user.profilePicture ? "transparent" : color}" onclick="viewProfile('${user.id}')">
        ${avHtml}
      </div>
      <div class="sug-info">
        <div class="sug-name" onclick="viewProfile('${user.id}')">${escHtml(user.name)}</div>
        <div class="sug-username">@${escHtml(user.username)}</div>
      </div>
      <button class="sug-follow-btn ${isFollowing ? "following" : ""}" onclick="toggleFollow('${user.id}')">
        ${isFollowing ? "Following" : "Follow"}
      </button>
    </div>
  `;
}

// ── SETTINGS ───────────────────────────────────────────────────
async function saveProfile() {
  if (!currentUser) return;

  const name = document.getElementById("settings-name").value.trim();
  const username = document.getElementById("settings-username").value.trim();
  const bio = document.getElementById("settings-bio").value.trim();
  const pictureInput = document.getElementById("settings-picture");

  if (!name || !username) {
    showAlert(document.getElementById("profile-alert"), "Name and username are required", "error");
    return;
  }

  const btn = document.getElementById("save-profile-btn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Saving...';

  try {
    let profilePicture = currentUser.profilePicture;
    if (pictureInput.files.length > 0) {
      profilePicture = await uploadImage(pictureInput.files[0]);
    }

    const updated = {
      ...currentUser,
      name,
      username,
      bio,
      profilePicture,
    };

    await api("PUT", `/api/users/${currentUser.id}`, updated);
    setCurrentUser(updated);
    showAlert(document.getElementById("profile-alert"), "Profile updated successfully!", "success");
  } catch (e) {
    showAlert(document.getElementById("profile-alert"), "Error: " + e.message, "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = "Save Changes";
  }
}

async function changePassword() {
  const current = document.getElementById("current-password").value;
  const newPass = document.getElementById("new-password").value;
  const confirm = document.getElementById("confirm-password").value;

  if (!current || !newPass || !confirm) {
    showAlert(document.getElementById("password-alert"), "All fields are required", "error");
    return;
  }

  if (newPass !== confirm) {
    showAlert(document.getElementById("password-alert"), "New passwords don't match", "error");
    return;
  }

  if (newPass.length < 6) {
    showAlert(document.getElementById("password-alert"), "Password must be at least 6 characters", "error");
    return;
  }

  const btn = document.getElementById("change-password-btn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Changing...';

  try {
    await api("POST", "/api/auth/change-password", {
      userId: currentUser.id,
      currentPassword: current,
      newPassword: newPass,
    });
    
    document.getElementById("current-password").value = "";
    document.getElementById("new-password").value = "";
    document.getElementById("confirm-password").value = "";
    
    showAlert(document.getElementById("password-alert"), "Password changed successfully!", "success");
  } catch (e) {
    showAlert(document.getElementById("password-alert"), "Error: " + e.message, "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = "Change Password";
  }
}

// ── HELPER FUNCTIONS ───────────────────────────────────────────
function escHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatTime(date) {
  const d = new Date(date);
  const now = new Date();
  const diff = Math.floor((now - d) / 1000);
  if (diff < 60) return "just now";
  if (diff < 3600) return Math.floor(diff / 60) + "m ago";
  if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
}

function showAlert(el, msg, type) {
  if (!el) return;
  el.textContent = msg;
  el.className = "alert " + type;
  el.style.display = "block";
}

let _tt;
function showToast(msg) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(_tt);
  _tt = setTimeout(() => t.classList.remove("show"), 2800);
}

function stringToColor(s) {
  const c = [
    "#7c6bff",
    "#ff5f7a",
    "#22d48f",
    "#f5a623",
    "#00b4d8",
    "#e040fb",
    "#26c6da",
    "#ff7043",
  ];
  let h = 0;
  for (let i = 0; i < s.length; i++) h = s.charCodeAt(i) + ((h << 5) - h);
  return c[Math.abs(h) % c.length];
}

// ── NAVIGATION HELPERS ─────────────────────────────────────────
function setActiveNav(page) {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.toggle("active", item.dataset.page === page);
  });
}

// ── BOOT ───────────────────────────────────────────────────────
function initializeApp() {
  applyTheme(localStorage.getItem("circle_theme") || "dark");
  
  try {
    const s = localStorage.getItem("circle_user");
    if (s) setCurrentUser(JSON.parse(s));
  } catch (e) {
    localStorage.removeItem("circle_user");
  }
  
  updateUserChip();
  loadUsers();
}

// Initialize on DOM ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}
